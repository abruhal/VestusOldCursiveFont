
 	-: TIRONIAN NOTES KEY :-


Tironian "AB"		| [)]
Tironian "AD"		| [(]
Tironian "ET" 		| [&]
Tironian "ERGO" 	| [@]
Tironian "NON"		| [~]
Tironian "QUO"		| [?] + [.]
Tironian "QUODAM"	| [?] + [!]
Tironian "QUONAM"	| [!] + [?]
Tironian "SED"		| [-]
Tironian "UBI"		| [$]

The "ET", "ERGO", "NON", and "SED" characters 
havewider spaces on each side and are 
intended to be used without spaces 
(interpuncts), for example to use Tironian "ET"
in the phrase "optumum et uerissumum" you would
write "optumum&uerissumum". 

Othet Tironian characters can be used with
regular spaces. 